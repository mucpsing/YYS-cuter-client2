export const EventList = ["selectFolder", "selectSaveFile", "exportFile", "selectJsonFile"]
