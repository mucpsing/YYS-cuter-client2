/*
 * @Author: CPS holy.dandelion@139.com
 * @Date: 2023-07-22 00:22:02
 * @LastEditors: CPS holy.dandelion@139.com
 * @LastEditTime: 2023-08-19 18:18:14
 * @FilePath: \YYS-cuter-client\src\components\ImageCuter\store\state.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

export default {
  showSettingsPage: false,
};
