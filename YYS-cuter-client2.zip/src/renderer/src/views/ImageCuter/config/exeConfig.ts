/*
 * @Author: CPS-surfacePro7 holy.dandelion@139.com
 * @Date: 2023-01-24 17:45:50
 * @LastEditors: CPS holy.dandelion@139.com
 * @LastEditTime: 2023-08-19 17:14:46
 * @FilePath: \yys-cuter-client\src\components\ImageCuter\config\exeConfig.ts
 * @Description: 远程服务器的配置
 */

export default {};
