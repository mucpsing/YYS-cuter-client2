<template>
  <div>
    {{ msg }}
  </div>
</template>

<script lang="ts" setup>
const msg = ref("This is Home Page");
</script>
