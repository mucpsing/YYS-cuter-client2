export default {
  error: (msg: string) => {
    console.log("[error]: ", msg);
  },
};
