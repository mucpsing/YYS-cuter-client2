import process from "process";

process.env["ELECTRON_DISABLE_SECURITY_WARNINGS"] = "true";
