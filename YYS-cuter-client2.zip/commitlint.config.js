export default {
  extends: ['cz'],
  // extends: ['cz'],
};
